The iPendant Controls are required for remote monitoring and display of the iPendant screens and for 
developing custom iPendant screens.  See the iPendant Customization Guide, a pdf file which was 
included with the files you downloaded, and the Advanced iPendant Functions Chapter in the Internet 
Options Setup and Operations Manual that came with your robot, for additional information about 
using these controls.